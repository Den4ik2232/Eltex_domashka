#include "client.h"
#include "graphic.h"
#include "network.h"

#include <ctype.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
volatile sig_atomic_t client_shutdown = 0;

void client_sigint_handler(int sig)
{
    (void)sig;
    client_shutdown = 1;
}

static int validate_ip(const char* ip)
{
    struct sockaddr_in sa;
    return inet_pton(AF_INET, ip, &sa.sin_addr) != 0;
}

static int validate_port(const char* port_str)
{
    bool is_digits = true;
    bool valid = false;

    for (const char* p = port_str; *p; p++)
    {
        if (!isdigit(*p))
        {
            is_digits = false;
            break;
        }
    }

    if (is_digits)
    {
        int port = atoi(port_str);
        if (port > 0 && port <= MAX_PORT)
        {
            valid = true;
        }
    }

    return valid ? 1 : 0;
}

int start_client()
{
    signal(SIGINT, client_sigint_handler);

    ConnectionParams connection_params;

    int valid_input = 0;

    while (!valid_input && !client_shutdown)
    {
        connection_params = start_connection_window();
        valid_input = 1;

        if (!validate_ip(connection_params.ip))
        {
            show_error_message("Invalid IP address format");
            valid_input = 0;
            continue;
        }

        if (!validate_port(connection_params.port))
        {
            show_error_message("Port must be 1-65535");
            valid_input = 0;
            continue;
        }
    }

    if (client_shutdown)
        return 0;

    init_graphic();

    int sock_fd = create_tcp_socket();

    if (connect_to_server(sock_fd, connection_params))
    {
        close(sock_fd);
        return 0;
    }

    if (send(sock_fd, connection_params.nickname, sizeof(connection_params.nickname), 0) <
        0)
    {
        perror("send");
        return 0;
    }

    Player player;
    ssize_t recv_size = recv(sock_fd, &player, sizeof(Player), 0);
    if (recv_size <= 0)
    {
        perror("Failed to receive player data");
        close(sock_fd);
        return 1;
    }

    player.server_sock = sock_fd;

    pthread_t input_thread;
    pthread_t thread_receive;

    pthread_create(&input_thread, NULL, player_input_thread, &player);
    pthread_create(&thread_receive, NULL, read_msg_client, &player);

    pthread_join(thread_receive, NULL);

    client_shutdown = 1;

    pthread_join(input_thread, NULL);

    // Перенос очистки в основной поток
    cleanup_ncurses();

    close(sock_fd);
    return 0;
}

int start_client_with_params(ConnectionParams connection_params)
{
    signal(SIGINT, client_sigint_handler);

    bool was_in_ncurses = !isendwin();
    if (was_in_ncurses)
    {
        def_prog_mode();
        endwin();
    }

    int sock_fd = create_tcp_socket();

    if (connect_to_server(sock_fd, connection_params))
    {
        close(sock_fd);
        if (was_in_ncurses)
        {
            reset_prog_mode();
            refresh();
            endwin();
        }
        return 1;
    }

    if (send(sock_fd, connection_params.nickname, sizeof(connection_params.nickname), 0) <
        0)
    {
        perror("send");
        if (was_in_ncurses)
        {
            reset_prog_mode();
            refresh();
        }
        return 1;
    }

    Player player;
    ssize_t recv_size = recv(sock_fd, &player, sizeof(Player), 0);
    if (recv_size <= 0)
    {
        endwin();
        perror("Failed to receive player data");
        close(sock_fd);
        if (was_in_ncurses)
        {
            reset_prog_mode();
            refresh();
            endwin();
        }
        return 1;
    }

    player.server_sock = sock_fd;

    if (was_in_ncurses)
    {
        reset_prog_mode();
        refresh();
    }
    else
    {
        init_graphic();
    }

    pthread_t input_thread;
    pthread_t thread_receive;

    pthread_create(&input_thread, NULL, player_input_thread, &player);
    pthread_create(&thread_receive, NULL, read_msg_client, &player);

    pthread_join(thread_receive, NULL);

    client_shutdown = 1;

    pthread_join(input_thread, NULL);

    // Перенос очистки в основной поток
    cleanup_ncurses();

    close(sock_fd);
    return 0;
}

#include "client.h"
#include "graphic.h"
#include "server.h"

#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void handle_sigint(int sig)
{
    (void)sig;
    endwin();
    printf("\nProgramm exit with Ctrl+C\n");
    exit(0);
}

void* server_thread(void* arg)
{
    (void)arg;
    if (start_server())
    {
        printf("Server failed to start\n");
        pthread_exit(NULL);
    }
    pthread_exit(NULL);
}

int main(void)
{
    signal(SIGINT, handle_sigint);
    signal(SIGPIPE, SIG_IGN);

    init_graphic();

    MenuChoice choice = start_menu();

    switch (choice)
    {
    case MENU_SERVER:
    {
        pthread_t server_tid;
        if (pthread_create(&server_tid, NULL, server_thread, NULL) != 0)
        {
            perror("pthread_create");
            return 1;
        }

        sleep(2); // Даем серверу время на запуск

        char nickname[50];
        ask_nickname(nickname);

        // Временно выходим из ncurses
        def_prog_mode(); // Сохраняем состояние
        endwin();        // Выходим в терминальный режим

        ConnectionParams params;
        strncpy(params.ip, "127.0.0.1", sizeof(params.ip)); // Используем localhost
        strncpy(params.port, "55555", sizeof(params.port));
        strncpy(params.nickname, nickname, sizeof(params.nickname));

        printf("Starting client as '%s'...\n", nickname);
        if (start_client_with_params(params))
        {
            printf("Client failed to start\n");
            // Восстанавливаем ncurses, чтобы корректно завершить
            reset_prog_mode();
            refresh();
            return 1;
        }

        // Возвращаемся в ncurses режим (хотя клиент завершился, но мы в main)
        // reset_prog_mode();
        // refresh();

        // Ожидаем завершения серверного потока
        pthread_join(server_tid, NULL);
        break;
    }
    case MENU_CLIENT:
        // endwin();
        // printf("You're client\n");
        if (start_client())
        {
            endwin();
            printf("Start client failed\n");
            return 0;
        }
        break;
    case MENU_EXIT:
        endwin();
        break;
    case MENU_ERROR:
        endwin();
        perror("Menu initialization failed\n");
        return 1;
    default:
        break;
    }

    cleanup_ncurses();
    return 0;
}

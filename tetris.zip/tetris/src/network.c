#include "network.h"
#include "game.h"
#include "graphic.h"
#include "player.h"

#include <curl/curl.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>

char white_ip[64] = {0};

static size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp)
{
    size_t total_size = size * nmemb;
    strncat((char*)userp, contents, total_size);
    return total_size;
}

void send_msg_connect(GameState game_state)
{
    for (int i = 0; i < game_state.player_count; i++)
    {
        send(game_state.players[i].socket, &game_state, sizeof(GameState), 0);
    }
}

static void network_ip(char* ip)
{
    CURL* curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();

    if (curl)
    {
        curl_easy_setopt(curl, CURLOPT_URL, "https://api.ipify.org");
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, ip);

        res = curl_easy_perform(curl);
        if (res != CURLE_OK)
        {
            return;
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();
}

int create_tcp_socket(void)
{
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd < 0)
    {
        perror("Socket creation failed");
    }
    return sock_fd;
}

int setup_listen_socket(int listen_sock)
{
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(PORT);

    socklen_t server_len = sizeof(server_addr);

    int opt = 1;
    if (setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)))
    {
        perror("setsockopt failed");
        close(listen_sock);
        return 1;
    }

    if (bind(listen_sock, (struct sockaddr*)&server_addr, server_len) < 0)
    {
        perror("Bind listen socket failed");
        close(listen_sock);
        return 1;
    }

    if (listen(listen_sock, MAX_CLIENTS) < 0)
    {
        perror("Listen failed");
        close(listen_sock);
        return 1;
    }

    if (getsockname(listen_sock, (struct sockaddr*)&server_addr, &server_len) < 0)
    {
        perror("Getsockname failed");
        close(listen_sock);
        return 1;
    }
    network_ip(white_ip);
    return 0;
}

int connect_to_server(int sock_fd, ConnectionParams connection_params)
{
    int port = atoi(connection_params.port);

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, connection_params.ip, &serv_addr.sin_addr) <= 0)
    {
        perror("Invalid address");
        close(sock_fd);
        return 1;
    }

    if (connect(sock_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("connect");
        close(sock_fd);
        return 1;
    }
    return 0;
}

int send_player_action(int sock, ActionMessage* action_message)
{
    if (send(sock, action_message, sizeof(ActionMessage), 0) < 0)
    {
        perror("Failed to send player data");
        return 1;
    }
    return 0;
}

void* read_msg_server(void* args)
{
    (void)args;

    while (!server_shutdown)
    {
        fd_set read_fds;
        FD_ZERO(&read_fds);
        int max_fd = 0;

        pthread_mutex_lock(&mutex_game_state);

        if (game_state.player_count == 0 || server_shutdown)
        {
            pthread_mutex_unlock(&mutex_game_state);
            usleep(100000);
            continue;
        }

        for (int i = 0; i < game_state.player_count; i++)
        {
            int fd = game_state.players[i].socket;
            if (fd > 0)
            {
                FD_SET(fd, &read_fds);
                if (fd > max_fd)
                {
                    max_fd = fd;
                }
            }
        }
        pthread_mutex_unlock(&mutex_game_state);

        if (max_fd == 0)
        {
            usleep(100000);
            continue;
        }

        struct timeval timeout = {0, 1000};
        int activity = select(max_fd + 1, &read_fds, NULL, NULL, &timeout);
        if (activity < 0)
        {
            if (server_shutdown)
            {
                break;
            }
            perror("select error");
            continue;
        }

        pthread_mutex_lock(&mutex_game_state);
        // Используем while вместо for для безопасного удаления
        int i = 0;
        while (i < game_state.player_count)
        {
            int sock = game_state.players[i].socket;
            if (sock <= 0)
            {
                i++;
                continue;
            }

            if (FD_ISSET(sock, &read_fds))
            {
                ActionMessage msg;
                int bytes_read = recv(sock, &msg, sizeof(msg), MSG_DONTWAIT);

                if (bytes_read <= 0)
                {
                    short player_id = game_state.players[i].id;
                    remove_player_from_gamestate(player_id);
                    send_msg_connect(game_state);
                    // Если вышел создатель сервера
                    if (player_id == game_state.creator_id)
                    {
                        game_state.game_over = true;
                        server_shutdown = 1;
                        pthread_mutex_unlock(&mutex_game_state);
                        return NULL; // Немедленный выход
                    }
                    continue;
                }
                else if (bytes_read == sizeof(ActionMessage))
                {
                    if (msg.action == 'q')
                    {
                        short player_id = msg.player_id;
                        remove_player_from_gamestate(player_id);
                        send_msg_connect(game_state);
                        // Если вышел создатель сервера
                        if (player_id == game_state.creator_id)
                        {
                            game_state.game_over = true;
                            server_shutdown = 1;
                            pthread_mutex_unlock(&mutex_game_state);
                            return NULL; // Немедленный выход
                        }
                        continue;
                    }
                    else if (msg.action == 'b')
                    {
                        if (msg.player_id == game_state.creator_id &&
                            !game_state.is_started)
                        {
                            game_state.is_started = true;
                            send_msg_connect(
                                game_state); // Рассылаем обновленное состояние
                        }
                    }
                    else if (msg.action == 'p')
                    {
                        game_state.is_paused = !game_state.is_paused;
                    }
                    else if (msg.player_id == game_state.active_player_id)
                    {
                        handle_player_action(&msg);
                    }
                }
            }
            i++;
        }

        pthread_mutex_unlock(&mutex_game_state);
    }
    return NULL;
}

void* send_msg_to_clients(void* args)
{
    (void)args;

    struct timespec last_update;
    clock_gettime(CLOCK_MONOTONIC, &last_update);

    while (!server_shutdown)
    {
        pthread_mutex_lock(&mutex_game_state);

        // Если сервер выключается, выходим
        if (server_shutdown)
        {
            pthread_mutex_unlock(&mutex_game_state);
            break;
        }

        // Если игра завершена, но есть игроки - отправляем финальное состояние
        if (game_state.game_over)
        {
            GameState current_state = game_state;
            int player_count = current_state.player_count;
            int sockets[MAX_CLIENTS];
            for (int i = 0; i < player_count; i++)
            {
                sockets[i] = current_state.players[i].socket;
            }
            pthread_mutex_unlock(&mutex_game_state);

            // Отправляем финальное состояние всем игрокам
            for (int i = 0; i < player_count; i++)
            {
                int sock = sockets[i];
                if (sock > 0)
                {
                    send(sock, &current_state, sizeof(GameState), 0);
                    close(sock);
                }
            }

            // Сбрасываем состояние игроков
            pthread_mutex_lock(&mutex_game_state);
            game_state.player_count = 0;
            game_state.active_player_id = -1;
            pthread_mutex_unlock(&mutex_game_state);

            continue;
        }
        if (client_shutdown && game_state.player_count == 0)
        {
            server_shutdown = 1;
            pthread_exit(NULL);
        }

        // Если нет игроков или игра на паузе, ждем
        if (game_state.player_count == 0 || game_state.is_paused)
        {
            pthread_mutex_unlock(&mutex_game_state);
            usleep(100000); // 100ms
            continue;
        }

        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        long elapsed_ns = (now.tv_sec - last_update.tv_sec) * 1000000000L +
                          (now.tv_nsec - last_update.tv_nsec);
        long remaining_ns = game_state.delay_time * 1000000L - elapsed_ns;

        if (remaining_ns > 0)
        {
            pthread_mutex_unlock(&mutex_game_state);
            usleep(remaining_ns / 1000);
            continue;
        }

        clock_gettime(CLOCK_MONOTONIC, &last_update);

        if (update_game())
        {
            game_state.game_over = true;
        }

        GameState current_state = game_state;
        int player_count = current_state.player_count;
        int sockets[MAX_CLIENTS];
        for (int i = 0; i < player_count; i++)
        {
            sockets[i] = current_state.players[i].socket;
        }
        pthread_mutex_unlock(&mutex_game_state);

        for (int i = 0; i < player_count; i++)
        {
            int sock = sockets[i];
            if (sock > 0)
            {
                send(sock, &current_state, sizeof(GameState), MSG_DONTWAIT);
            }
        }
    }

    return NULL;
}

void* read_msg_client(void* args)
{
    Player player = *(Player*)args;
    struct timespec last_frame;
    clock_gettime(CLOCK_MONOTONIC, &last_frame);

    init_graphic();

    GameState new_state;
    bool game_ended = false;
    short my_id = player.id;
    int my_score = 0;

    while (!client_shutdown)
    {
        check_resize(my_id, white_ip);
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        long elapsed_ns = (now.tv_sec - last_frame.tv_sec) * 1000000000L +
                          (now.tv_nsec - last_frame.tv_nsec);

        if (elapsed_ns < 16666666L)
        {
            usleep((16666666L - elapsed_ns) / 1000);
            continue;
        }

        clock_gettime(CLOCK_MONOTONIC, &last_frame);

        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(player.server_sock, &read_fds);

        struct timeval timeout = {0, 0};
        int select_result =
            select(player.server_sock + 1, &read_fds, NULL, NULL, &timeout);
        if (select_result > 0)
        {
            ssize_t recv_size =
                recv(player.server_sock, &new_state, sizeof(GameState), MSG_DONTWAIT);

            if (recv_size > 0)
            {
                if (!new_state.is_started)
                {
                    show_waiting_screen(new_state, my_id, white_ip);
                    if (waiting_win)
                    {
                        wnoutrefresh(waiting_win);
                    }
                    doupdate();
                }
                else
                {
                    if (!new_state.game_over)
                    {
                        for (int i = 0; i < new_state.player_count; i++)
                        {
                            if (new_state.players[i].id == my_id)
                            {
                                my_score = new_state.players[i].score;
                                break;
                            }
                        }
                        if (!game_win)
                        {
                            if (create_players_window())
                            {
                                cleanup_ncurses();
                                client_shutdown = 1;
                                pthread_exit(NULL);
                            }
                        }

                        show_game_managment();
                        show_my_figure(player);
                        show_game_field(new_state);
                        show_players_n_stats(new_state);

                        // Буферизированное обновление окон
                        if (game_win)
                        {
                            wnoutrefresh(game_win);
                        }
                        if (stats_win)
                        {
                            wnoutrefresh(stats_win);
                        }
                        if (figure_win)
                        {
                            wnoutrefresh(figure_win);
                        }
                        if (management_win)
                        {
                            wnoutrefresh(management_win);
                        }
                        doupdate(); // <-- Единое обновление экрана
                    }
                    else if (!game_ended)
                    {
                        game_ended = true;
                        show_game_over_screen(new_state, my_score);
                    }
                }
            }
            else if (recv_size == 0)
            {
                if (!game_ended)
                {
                    show_personal_game_over_screen(my_score);
                    game_ended = true;
                }
                while (!client_shutdown)
                {
                    int ch = getch();
                    if (ch == 'q' || ch == 'Q')
                    {
                        client_shutdown = 1;
                        break;
                    }
                    usleep(10000);
                }
                break;
            }
        }
        else if (select_result < 0)
        {
            if (!game_ended)
            {
                perror("select error");
                break;
            }
        }

        if (game_ended)
        {
            int ch = getch();
            if (ch == 'q' || ch == 'Q')
            {
                client_shutdown = 1;
                break;
            }
        }
    }

    close(player.server_sock);
    client_shutdown = 1;
    return NULL;
}

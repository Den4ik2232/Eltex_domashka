#include "server.h"
#include "game.h"
#include "network.h"
#include "player.h"

#include <signal.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>

volatile sig_atomic_t server_shutdown = 0;

void server_sigint_handler(int sig)
{
    (void)sig;
    server_shutdown = 1;
}

GameState game_state = {0};
pthread_mutex_t mutex_game_state = PTHREAD_MUTEX_INITIALIZER;

static void* handle_connections(void* args)
{
    int listen_sock = *(int*)args;

    while (!server_shutdown)
    {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        memset(&client_addr, 0, sizeof(client_addr));

        fd_set read_fds;
        FD_ZERO(&read_fds);
        FD_SET(listen_sock, &read_fds);
        struct timeval timeout = {1, 0};

        if (select(listen_sock + 1, &read_fds, NULL, NULL, &timeout) < 0)
        {
            if (server_shutdown)
                break;
            continue;
        }

        if (!FD_ISSET(listen_sock, &read_fds))
            continue;

        int client_sock =
            accept(listen_sock, (struct sockaddr*)&client_addr, &client_len);
        if (client_sock < 0)
        {
            if (server_shutdown)
                break;
            perror("Accept failed\n");
            continue;
        }

        pthread_mutex_lock(&mutex_game_state);
        if (game_state.player_count >= MAX_CLIENTS || server_shutdown)
        {
            close(client_sock);
            pthread_mutex_unlock(&mutex_game_state);
            continue;
        }

        char nickname[50];
        if (recv(client_sock, nickname, sizeof(nickname), 0) < 0)
        {
            perror("server recv");
            pthread_mutex_unlock(&mutex_game_state);
            close(client_sock);
            continue;
        }

        Player new_player = init_player(client_sock, nickname);
        add_player_to_gamestate(&new_player);
        if (game_state.player_count == 1)
        {
            game_state.creator_id = new_player.id; // Запоминаем создателя
        }
        // Копируем состояние под мьютексом
        // GameState current_state = game_state;
        pthread_mutex_unlock(&mutex_game_state);

        // Отправляем данные игрока
        if (send(client_sock, &new_player, sizeof(Player), 0) < 0)
        {
            perror("Failed to send player data");
        }
        send_msg_connect(game_state);
        // Отправляем текущее состояние игры
        // if (send(client_sock, &current_state, sizeof(GameState), 0) < 0)
        // {
        //     perror("Failed to send game state");
        // }
    }

    return NULL;
}

int start_server(void)
{
    signal(SIGINT, server_sigint_handler);

    srand(time(NULL));
    memset(&game_state, 0, sizeof(game_state));
    game_state.delay_time = 200;
    game_state.active_player_id = -1;
    game_state.next_player_id = 1; // Начинаем ID с 1
    game_state.is_started = false;

    int listen_sock = create_tcp_socket();
    if (setup_listen_socket(listen_sock))
    {
        close(listen_sock);
        return 1;
    }

    game_init();

    pthread_t accept_clients_thread;
    pthread_t receive_client_message;
    pthread_t send_clients_thread;

    pthread_create(&accept_clients_thread, NULL, handle_connections, &listen_sock);
    pthread_create(&receive_client_message, NULL, read_msg_server, NULL);
    pthread_create(&send_clients_thread, NULL, send_msg_to_clients, NULL);

    // Главный поток отслеживает состояние завершения
    while (!server_shutdown)
    {
        pthread_mutex_lock(&mutex_game_state);
        int should_exit = game_state.game_over && game_state.player_count == 0;
        pthread_mutex_unlock(&mutex_game_state);

        if (should_exit)
        {
            server_shutdown = 1;
            break;
        }

        sleep(1);
    }

    // Устанавливаем флаг завершения
    server_shutdown = 1;

    // Закрываем слушающий сокет, чтобы разблокировать accept()
    close(listen_sock);

    // Ожидаем завершения потоков
    pthread_join(accept_clients_thread, NULL);
    pthread_join(receive_client_message, NULL);
    pthread_join(send_clients_thread, NULL);

    // printf("Server stopped\n");
    return 0;
}

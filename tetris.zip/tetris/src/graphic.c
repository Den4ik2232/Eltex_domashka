#include "graphic.h"
#include <ncurses.h>
#include <pthread.h>

WINDOW* game_win = NULL;
WINDOW* management_win = NULL;
WINDOW* stats_win = NULL;
WINDOW* figure_win = NULL;
WINDOW* waiting_win = NULL;

static volatile sig_atomic_t resize_flag = 0;

static int center_x(int width)
{
    int cols = getmaxx(stdscr);
    return (cols - width) / 2;
}

// Функция для центрирования окна по вертикали
static int center_y(int height)
{
    int rows = getmaxy(stdscr);
    return (rows - height) / 3;
}

WINDOW* create_window(int start_y,
                      int start_x,
                      int height,
                      int width,
                      Color main_color,
                      Color background_color,
                      const char* header_1,
                      const char* header_2)
{
    WINDOW* win = newwin(height, width, start_y, start_x);
    if (win == NULL)
    {
        perror("Error creating window\n");
        return NULL;
    }

    wbkgd(win, COLOR_PAIR(main_color));

    WINDOW* frame = newwin(height + 2, width + 2, start_y - 1, start_x - 1);
    if (frame == NULL)
    {
        delwin(win);
        perror("Error creating frame\n");
        return NULL;
    }

    wbkgd(frame, COLOR_PAIR(background_color));

    if (header_1 && *header_1)
    {
        wattron(frame, A_BOLD);
        mvwprintw(frame, 0, 1, "%s", header_1);
        wattroff(frame, A_BOLD);
    }

    if (header_2 && *header_2)
    {
        int text_x = (width - strlen(header_2));
        wattron(frame, A_BOLD);
        mvwprintw(frame, 0, text_x, "%s", header_2);
        wattroff(frame, A_BOLD);
    }

    wrefresh(frame);
    wrefresh(win);

    delwin(frame);

    return win;
}

static void init_color_pairs(void)
{
    init_pair(BACKGROUND, RED_COLOR_CODE, BACKGROUND_COLOR_CODE);
    init_pair(FIELD, BLACK_COLOR_CODE, FIELD_COLOR_CODE);
    init_pair(FRAME, BLACK_COLOR_CODE, FRAME_COLOR_CODE);
    init_pair(BLUE, BLACK_COLOR_CODE, BLUE_COLOR_CODE);
    init_pair(YELLOW, BLACK_COLOR_CODE, YELLOW_COLOR_CODE);
    init_pair(PURPLE, BLACK_COLOR_CODE, PURPLE_COLOR_CODE);
    init_pair(GREEN, BLACK_COLOR_CODE, GREEN_COLOR_CODE);
    init_pair(RED, BLACK_COLOR_CODE, RED_COLOR_CODE);
    init_pair(LIGHT_BLUE, BLACK_COLOR_CODE, LIGHT_BLUE_COLOR_CODE);
    init_pair(ORANGE, BLACK_COLOR_CODE, ORANGE_COLOR_CODE);
}

void handle_resize(int sig)
{
    (void)sig;
    resize_flag = 1;
}

void check_resize(short my_id, char* ip)
{
    if (resize_flag)
    {
        resize_flag = 0;
        def_prog_mode();
        endwin();
        refresh();
        clear();

        // Удаляем старые окна
        delwin(game_win);
        delwin(stats_win);
        delwin(figure_win);
        delwin(management_win);
        delwin(waiting_win);

        game_win = NULL;
        stats_win = NULL;
        figure_win = NULL;
        management_win = NULL;
        waiting_win = NULL;

        clear();
        refresh();

        // Получаем текущие размеры терминала
        int rows, cols;
        getmaxyx(stdscr, rows, cols);

        if (game_state.is_started)
        {
            // Проверяем минимальные требования для создания окон
            const int grid_pixel_height = GRID_HEIGHT;
            const int grid_pixel_width = GRID_WIDTH * 2;
            const int stats_win_width = grid_pixel_width + 10;
            const int figure_win_width = 10;
            const int management_win_height = 5;

            // Минимальные требования к размерам
            const int min_cols =
                grid_pixel_width + stats_win_width + figure_win_width + 4;
            const int min_rows = grid_pixel_height + management_win_height + 2;

            if (cols >= min_cols && rows >= min_rows)
            {
                // Размеры достаточны - создаем окна
                if (create_players_window() == 0)
                {
                    if (game_win)
                        wnoutrefresh(game_win);
                    if (stats_win)
                        wnoutrefresh(stats_win);
                    if (figure_win)
                        wnoutrefresh(figure_win);
                    if (management_win)
                        wnoutrefresh(management_win);
                    doupdate();
                }
            }
            else
            {
                // Размеры недостаточны - показываем сообщение об ошибке
                show_error_message("Terminal too small! Resize and wait...");
            }
        }
        else
        {
            // Для экрана ожидания - аналогичная логика как для create_players_window
            show_waiting_screen(game_state, my_id, ip);
        }

        reset_prog_mode();
    }
}

void init_graphic()
{
    initscr();
    cbreak();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    start_color();
    // use_default_colors();
    init_color_pairs();
    set_escdelay(0);
    signal(SIGWINCH, handle_resize);
}

MenuChoice start_menu()
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 10;
    int width = 30;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* menu_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, NULL, NULL);

    if (menu_win == NULL)
    {
        endwin();
        perror("Error when creating windows\n");
        return MENU_ERROR;
    }

    keypad(menu_win, true);

    char* choices[] = {"Server", "Client", "Exit"};

    int n_choices = sizeof(choices) / sizeof(char*);
    int highlight = 0;
    int should_exit = 0;

    while (!should_exit)
    {
        for (int i = 0; i < n_choices; i++)
        {
            if (i == highlight)
            {
                wattron(menu_win, A_REVERSE);
                wattron(menu_win, A_BOLD);
                mvwprintw(
                    menu_win, i + 3, (width - strlen(choices[i])) / 2, "%s", choices[i]);
                wattroff(menu_win, A_BOLD);
                wattroff(menu_win, A_REVERSE);
            }
            else
            {
                wattron(menu_win, A_BOLD);
                mvwprintw(
                    menu_win, i + 3, (width - strlen(choices[i])) / 2, "%s", choices[i]);
                wattroff(menu_win, A_BOLD);
            }
        }

        wrefresh(menu_win);

        int ch = wgetch(menu_win);

        switch (ch)
        {
        case KEY_UP:
            highlight--;
            if (highlight == -1)
            {
                highlight = n_choices - 1;
            }
            break;
        case KEY_DOWN:
            highlight++;
            if (highlight == n_choices)
            {
                highlight = 0;
            }
            break;
        case ENTER_KEY:
            should_exit = 1;
            break;
        case ESC_KEY:
            highlight = n_choices - 1;
            should_exit = 1;
            break;
        default:
            break;
        }
    }

    delwin(menu_win);
    clear();
    refresh();

    return highlight;
}

ConnectionParams start_connection_window()
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 8;
    int width = 40;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* input_win = create_window(
        start_y, start_x, height, width, FIELD, FRAME, "Client Connection", NULL);

    keypad(input_win, TRUE);
    echo();

    ConnectionParams connection_params = {0};

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 1, 2, "Nickname: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(
        input_win, connection_params.nickname, sizeof(connection_params.nickname) - 1);

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 3, 2, "Server IP: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(input_win, connection_params.ip, sizeof(connection_params.ip) - 1);

    wattron(input_win, A_BOLD);
    mvwprintw(input_win, 5, 2, "Port: ");
    wattroff(input_win, A_BOLD);

    wgetnstr(input_win, connection_params.port, sizeof(connection_params.port) - 1);

    noecho();
    delwin(input_win);
    clear();
    refresh();

    return connection_params;
}

void ask_nickname(char* nickname)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 8;
    int width = 40;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* input_win = create_window(
        start_y, start_x, height, width, FIELD, FRAME, "Client Connection", NULL);

    keypad(input_win, TRUE);
    echo();
    mvwprintw(input_win, 1, 2, "Enter your nickname: ");
    mvwgetnstr(input_win, 2, 2, nickname, MAX_NICKNAME_LENGTH - 1);
    noecho();
    delwin(input_win);
    clear();
    refresh();
}

void show_error_message(const char* msg)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    int height = 3;
    int width = strlen(msg) + 4;
    int start_y = (rows - height) / 2;
    int start_x = (cols - width) / 2;

    WINDOW* err_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, "Error!", NULL);

    if (!err_win)
    {
        endwin();
        return;
    }

    mvwprintw(err_win, 1, 2, "%s", msg);
    wrefresh(err_win);
    napms(2000);
    delwin(err_win);
    clear();
    refresh();
}

int create_players_window(void)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    // Размеры игрового поля (в символах)
    const int grid_pixel_height = GRID_HEIGHT;   // 20 строк
    const int grid_pixel_width = GRID_WIDTH * 2; // 10 колонок × 2 символа

    // Размеры окна статистики (ширина = 1.5 × ширине игрового поля)
    const int stats_win_width = grid_pixel_width + 10; // Пример: 30 символов

    // Размеры окна фигуры (4×4 блока + отступы)
    const int figure_win_height = 6; // 4 строки + рамка
    const int figure_win_width = 10; // 4 колонки × 2 символа + рамка

    // Размеры окна управления (фиксированная высота)
    const int management_win_height = 5;

    // Проверка минимальных размеров терминала
    if (cols < grid_pixel_width + stats_win_width + figure_win_width ||
        rows <= grid_pixel_height + management_win_height)
    {
        show_error_message("Terminal too small!");
        return 1;
    }

    // Позиционирование окон
    int group_width = grid_pixel_width + stats_win_width + 2;
    int start_x = center_x(group_width);
    int start_y = center_y(grid_pixel_height);

    int figure_x = start_x - figure_win_width - 2;
    if (figure_x < 0)
    {
        // Если не помещается слева, пробуем разместить справа
        figure_x = start_x + group_width + 2;
        if (figure_x + figure_win_width > cols)
        {
            // Если и справа не помещается, уменьшаем отступ
            figure_x = start_x + group_width;
        }
    }

    game_win = create_window(start_y,
                             start_x,
                             grid_pixel_height,
                             grid_pixel_width,
                             FIELD,
                             FRAME,
                             "Tetris",
                             NULL);
    if (!game_win)
    {
        endwin();
        return 1;
    }

    // Создаем окно статистики (справа от игрового поля)
    stats_win = create_window(start_y,
                              start_x + grid_pixel_width + 2,
                              grid_pixel_height,
                              stats_win_width,
                              FIELD,
                              FRAME,
                              "Player",
                              "Score");
    if (!stats_win)
    {
        endwin();
        return 1;
    }

    // Создаем окно фигуры (слева или справа от игрового поля)
    figure_win = create_window(start_y,
                               figure_x,
                               figure_win_height,
                               figure_win_width,
                               FIELD,
                               FRAME,
                               "My figure",
                               NULL);
    if (!figure_win)
    {
        endwin();
        return 1;
    }

    // Создаем окно управления (внизу под игровым полем и статистикой)
    management_win = create_window(start_y + grid_pixel_height + 1,
                                   start_x,
                                   management_win_height,
                                   group_width,
                                   FIELD,
                                   FRAME,
                                   "Controls",
                                   NULL);
    if (!management_win)
    {
        endwin();
        return 1;
    }

    wrefresh(game_win);
    wrefresh(stats_win);
    wrefresh(figure_win);
    wrefresh(management_win);
    return 0;
}

void show_players_n_stats(GameState new_state)
{
    if (!stats_win)
    {
        endwin();
        return;
    }

    int max_players = (GRID_HEIGHT / 2 + 2) - 2;
    for (int i = 0; i < max_players; i++)
    {
        wmove(stats_win, i + 1, 1);
        wclrtoeol(stats_win);
    }

    for (int i = 0; i < new_state.player_count && i < max_players; i++)
    {
        wattron(stats_win, A_BOLD);
        if (new_state.players[i].id == new_state.active_player_id)
        {
            wattron(stats_win, A_REVERSE);
        }
        mvwprintw(stats_win, i + 1, 1, "%-20s", new_state.players[i].nickname);
        mvwprintw(stats_win, i + 1, 22, "%6d", new_state.players[i].score);

        if (new_state.players[i].id == new_state.active_player_id)
        {
            wattroff(stats_win, A_REVERSE);
        }
        wattroff(stats_win, A_BOLD);
    }
    // Обновление окна после вывода информации
    wrefresh(stats_win); // <-- Добавлена эта строка
}

void show_game_managment(void)
{
    if (!management_win)
    {
        endwin();
        return;
    }

    char pause[] = "p/P - pause";
    char rotation[] = "^ - rotation";
    char boost[] = "SPACE - boost";
    const int width = 2 * (GRID_WIDTH * 2);

    int boost_x = (width - strlen(pause) - strlen(boost));
    int movement_x = (width - strlen(rotation));
    int exit_x = (width - strlen(pause) + 5);

    wattron(management_win, A_BOLD);
    mvwprintw(management_win, 1, 2, "p/P - pause");
    mvwprintw(management_win, 1, boost_x, "SPACE - boost");
    mvwprintw(management_win, 3, 2, "^ - rotation");
    mvwprintw(management_win, 3, movement_x, "<  > - movement");
    mvwprintw(management_win, 1, exit_x, "q/Q - exit");
    wattroff(management_win, A_BOLD);

    wrefresh(management_win);
}

void show_my_figure(Player player)
{
    if (!figure_win)
    {
        endwin();
        return;
    }

    int start_x = 2;
    int start_y = 2;

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (shapes[player.figure.figure_type][0][i][j])
            {
                wattron(figure_win, COLOR_PAIR(player.figure.color));
                mvwprintw(figure_win, start_y + i, start_x + j * 2, "  ");
                wattroff(figure_win, COLOR_PAIR(player.figure.color));
            }
        }
    }
    wrefresh(figure_win);
}

void show_game_field(GameState new_state)
{
    if (!game_win)
    {
        endwin();
        return;
    }

    // Вместо полного стирания - рисуем только изменения
    for (int i = 0; i < GRID_HEIGHT; i++)
    {
        for (int j = 0; j < GRID_WIDTH; j++)
        {
            if (new_state.grid[i][j])
            {
                wattron(game_win, COLOR_PAIR(new_state.grid[i][j]));
                mvwprintw(game_win, i, j * 2, "  ");
                wattroff(game_win, COLOR_PAIR(new_state.grid[i][j]));
            }
            else
            {
                // Очищаем только если было заполнено ранее
                wattron(game_win, COLOR_PAIR(FIELD));
                mvwprintw(game_win, i, j * 2, "  ");
                wattroff(game_win, COLOR_PAIR(FIELD));
            }
        }
    }

    // Находим активного игрока по id
    Player* active_player = NULL;
    for (int idx = 0; idx < new_state.player_count; idx++)
    {
        if (new_state.players[idx].id == new_state.active_player_id)
        {
            active_player = &new_state.players[idx];
            break;
        }
    }

    // Отрисовка текущей фигуры активного игрока, если он есть
    if (active_player)
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if (shapes[active_player->figure.figure_type]
                          [active_player->figure.rotation][i][j])
                {
                    int y = active_player->figure.y + i;
                    int x = (active_player->figure.x + j) * 2;
                    if (y >= 0 && y < GRID_HEIGHT && x >= 0 && x < GRID_WIDTH * 2)
                    {
                        wattron(game_win, COLOR_PAIR(active_player->figure.color));
                        mvwprintw(game_win, y, x, "  ");
                        wattroff(game_win, COLOR_PAIR(active_player->figure.color));
                    }
                }
            }
        }
    }

    wrefresh(game_win);
}

void cleanup_ncurses(void)
{
    // Безопасное удаление окон с проверкой указателей
    if (game_win)
    {
        delwin(game_win);
        game_win = NULL;
    }
    if (stats_win)
    {
        delwin(stats_win);
        stats_win = NULL;
    }
    if (management_win)
    {
        delwin(management_win);
        management_win = NULL;
    }
    if (figure_win)
    {
        delwin(figure_win);
        figure_win = NULL;
    }
    endwin();
    clear();
}

void show_game_over_screen(GameState state, short score)
{
    // Удаление старых окон перед созданием экрана завершения
    if (stats_win)
    {
        delwin(stats_win);
        stats_win = NULL;
    }
    if (management_win)
    {
        delwin(management_win);
        management_win = NULL;
    }
    if (game_win)
    {
        delwin(game_win);
        game_win = NULL;
    }
    if (figure_win)
    {
        delwin(figure_win);
        figure_win = NULL;
    }

    // Сохраняем текущие размеры терминала
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    // Очищаем экран
    clear();
    refresh();

    int width = 40;
    int height = 10;
    int start_x = (cols - width) / 2;
    int start_y = (rows - height) / 2;

    WINDOW* result_win = create_window(
        start_y, start_x, height, width, FIELD, FRAME, "Game Results", NULL);

    if (!result_win)
    {
        endwin();
        return;
    }

    // Выводим результаты
    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 2, 2, "Your final score: %d", score);
    mvwprintw(result_win, 4, 2, "Best player score: %d", state.max_score);
    mvwprintw(result_win, 6, 2, "Total players score: %d", state.common_score);
    wattroff(result_win, A_BOLD);

    // Выводим инструкцию
    const char* msg = "Press 'Q' to exit";
    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 8, (width - strlen(msg)) / 2, "%s", msg);
    wattroff(result_win, A_BOLD);

    wrefresh(result_win);

    delwin(result_win);
}

void show_waiting_screen(GameState state, short my_id, char* ip)
{
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    const int min_waiting_width = 40;
    const int min_waiting_height = 7;

    // Проверяем минимальные размеры
    if (cols < min_waiting_width || rows < min_waiting_height)
    {
        show_error_message("Terminal too small for waiting screen!");
        return;
    }

    // Вычисляем размеры окна
    int height = MAX(min_waiting_height, state.player_count + 5);
    height = MIN(height, rows - 4);
    int width = min_waiting_width;

    // Если окно еще не создано или изменилось количество игроков
    if (!waiting_win || height != getmaxy(waiting_win))
    {
        if (waiting_win)
        {
            clear();
            refresh();
            delwin(waiting_win);
        }

        waiting_win = create_window((rows - height) / 2,
                                    (cols - width) / 2,
                                    height,
                                    width,
                                    FIELD,
                                    FRAME,
                                    "Waiting for players",
                                    ip);

        if (!waiting_win)
        {
            endwin();
            return;
        }

        // Включаем буферизацию ввода
        keypad(waiting_win, TRUE);
        nodelay(waiting_win, TRUE);
    }

    werase(waiting_win);

    // Заголовок
    wattron(waiting_win, A_BOLD);
    mvwprintw(waiting_win, 1, 2, "Connected players (%d):", state.player_count);
    wattroff(waiting_win, A_BOLD);

    // Список игроков
    for (int i = 0; i < state.player_count && i < (height - 4); i++)
    {
        mvwprintw(waiting_win, i + 3, 4, "%s", state.players[i].nickname);
        if (state.players[i].id == state.creator_id)
        {
            mvwprintw(waiting_win, i + 3, width - 10, "(Host)");
        }
    }

    // Очищаем строку с сообщениями
    wmove(waiting_win, height - 2, 1);
    wclrtoeol(waiting_win);

    const char* msg;
    if (state.creator_id == my_id) // Проверяем, является ли текущий клиент хостом
    {
        msg = "Press ENTER to start the game";
    }
    else
    {
        msg = "Waiting for host to start...";
    }

    wattron(waiting_win, A_BOLD);
    mvwprintw(waiting_win, height - 2, (width - strlen(msg)) / 2, "%s", msg);
    wattroff(waiting_win, A_BOLD);

    wrefresh(waiting_win);
}

void cleanup_waiting(void)
{
    if (waiting_win)
    {
        delwin(waiting_win);
        waiting_win = NULL;
    }
}

void show_personal_game_over_screen(int score)
{
    if (stats_win)
    {
        delwin(stats_win);
        stats_win = NULL;
    }
    if (management_win)
    {
        delwin(management_win);
        management_win = NULL;
    }
    if (game_win)
    {
        delwin(game_win);
        game_win = NULL;
    }
    if (figure_win)
    {
        delwin(figure_win);
        figure_win = NULL;
    }

    // Сохраняем текущие размеры терминала
    int rows, cols;
    getmaxyx(stdscr, rows, cols);

    // Очищаем экран
    clear();
    refresh();

    int width = 40;
    int height = 10;
    int start_x = (cols - width) / 2;
    int start_y = (rows - height) / 2;

    WINDOW* result_win =
        create_window(start_y, start_x, height, width, FIELD, FRAME, "Game Over", NULL);

    if (!result_win)
    {
        endwin();
        return;
    }

    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 2, 2, "Your final score: %d", score);
    wattroff(result_win, A_BOLD);

    const char* msg = "Press 'Q' to exit";
    wattron(result_win, A_BOLD);
    mvwprintw(result_win, 6, (width - strlen(msg)) / 2, "%s", msg);
    wattroff(result_win, A_BOLD);

    wrefresh(result_win);
    delwin(result_win);
}

#ifndef NETWORK_H
#define NETWORK_H

#include "common.h"

#include <arpa/inet.h>
#include <errno.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define PORT 55555

int create_tcp_socket(void);
int setup_listen_socket(int listen_sock);
int connect_to_server(int sock_fd, ConnectionParams connection_params);
int send_player_action(int sock, ActionMessage* action_message);

void* read_msg_server(void* args);
void* send_msg_to_clients(void* args);
void* read_msg_client(void* args);

void send_msg_connect(GameState game_state);

#endif

#ifndef CLIENT_H
#define CLIENT_H

#include "common.h"
#include "graphic.h"
#include "input.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_PORT 65535

extern volatile sig_atomic_t client_shutdown;
int start_client();
int start_client_with_params(ConnectionParams connection_params);
void* read_msg_client(void* args); // Добавлено объявление

#endif

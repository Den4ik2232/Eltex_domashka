#ifndef INPUT_H
#define INPUT_H

#include "common.h"
#include "network.h"
#include <ncurses.h>

#define ENTER_KEY 10

void* player_input_thread(void* arg);

#endif

#ifndef SERVER_H
#define SERVER_H

#include "common.h"
#include "graphic.h"

#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <time.h>
#include <unistd.h>

extern volatile sig_atomic_t server_shutdown;
int start_server(void);

#endif

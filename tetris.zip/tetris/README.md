# Tetris

Данный проект представляет собой консольную игру "Тетрис" с псевдографикой.

# Запуск
## 1. Зависимости и библиотеки

Компилятор gcc и утилита make
```bash
sudo apt update
```

```bash
sudo apt -y install build-essential 
```

Библиотека `ncurses` для псевдографики
```bash
sudo apt update
```

```bash
sudo apt -y install libncurses-dev llibncurses6 libncursesw6  
```

Библиотека `curl` для работы с ip
```bash
sudo apt install libcurl4-openssl-dev
```
## 2. Сборка и запуск

Перейдите в директорию с проектом.
```bash
cd tetris/
```

Соберите бинарный файл при помощи `make`:
```bash
make
```

Запустите бинарный файл:
```bash
./tetris
```
или
```bash
make run
```

## 3. После игры

После того как вы поиграли и захотел удалить все объектные и бинарный файл:
```bash
make clean
```
